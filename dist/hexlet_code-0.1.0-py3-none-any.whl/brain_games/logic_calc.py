def calc():
    sign = ["+", "-", "*"]
    random_number1 = random.randint(0, 20)
    random_number2 = random.randint(0, 20)
    random_sign = random.choice(sign)
    result = 0
    if random_sign == '+':
        result = random_number1 + random_number2
    elif random_sign == '-':
        result = random_number1 - random_number2
    elif random_sign == '*':
        result = random_number1 * random_number2
