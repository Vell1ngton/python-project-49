### Hexlet tests and linter status:
[![Actions Status](https://github.com/Vell1ngton/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Vell1ngton/python-project-49/actions)

<a href="https://codeclimate.com/github/Vell1ngton/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/e3a6cd70fd0c680762bf/maintainability" /></a>

<a href="https://codeclimate.com/github/Vell1ngton/python-project-49/test_coverage"><img src="https://api.codeclimate.com/v1/badges/e3a6cd70fd0c680762bf/test_coverage" /></a>

BRAIN-GAMES
<a href="https://asciinema.org/a/9kUIhcCkeNYgnZ14LeHZnIVso" target="_blank"><img src="https://asciinema.org/a/9kUIhcCkeNYgnZ14LeHZnIVso.svg" /></a>

CALCULATOR
<a href="https://asciinema.org/a/SZHHBpl1ww64LdjFVezmS56w2" target="_blank"><img src="https://asciinema.org/a/SZHHBpl1ww64LdjFVezmS56w2.svg" /></a>

NOD
<a href="https://asciinema.org/a/AL7N0KvzVpcQGNR2L6vlkbjWw" target="_blank"><img src="https://asciinema.org/a/AL7N0KvzVpcQGNR2L6vlkbjWw.svg" /></a>

PROGRESSION
<a href="https://asciinema.org/a/XseAL1sq3ATHIQGba6mQIDxLc" target="_blank"><img src="https://asciinema.org/a/XseAL1sq3ATHIQGba6mQIDxLc.svg" /></a>

IS_PRIME
<a href="https://asciinema.org/a/6LjwC5AOEwH2KUcXdY9zxmCkd" target="_blank"><img src="https://asciinema.org/a/6LjwC5AOEwH2KUcXdY9zxmCkd.svg" /></a>